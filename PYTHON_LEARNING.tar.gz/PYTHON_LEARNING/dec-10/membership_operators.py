print(3 in [1, 2, 3])         # True
print("a" in "apple")         # True
print(10 in (5, 8, 10))       # True
print("x" in "hello")         # False


print(5 not in [1, 2, 3])      # True
print("z" not in "hello")      # True
print(10 not in (5, 10, 15))   # False

