# and, or, not, xor


print( True and True)   #if both are true only true otherwise false
a=5
print( a<5 and a==5)

print( True or False)   #if any one of them is true , o/p is True othewise false

print( not True)
print( not False)    #if true- o/p false, viceversa


print ( True ^ False)   #if both are different True&false o/p is True, is same False
print ( False ^ True)
print(False ^ False)
print( True ^ True )
