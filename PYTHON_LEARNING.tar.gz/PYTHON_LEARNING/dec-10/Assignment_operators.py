# = , +=, -=, *=, /=

a=5
a+=6
print(a)

a-=2
print(a)

a/=4
print(a)


a*=2
print(a)


