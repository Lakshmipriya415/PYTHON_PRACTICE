#== , !=, > , <, >=, <=



print(5==5)
print(1!=0)
print(5<=25)
print(5>=25)
print(3<2)
print(2>5)
