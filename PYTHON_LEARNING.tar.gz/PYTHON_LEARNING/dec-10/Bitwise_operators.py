# &,|, ^, ~, <<, >>


print(5&3)
print(5|3)
print(5^3)
print(~3)
print(5<<1)
print(5>>1)
print(5<<2)
