"""
a = [1, 2, 3]
b = a
print(a is b)        # True → both refer to the same list


x = 10
y = 10
print(x is not y)   # False → small integers share memory
"""



x = -1
if x:
    print("Yes")
else:
    print("No")
