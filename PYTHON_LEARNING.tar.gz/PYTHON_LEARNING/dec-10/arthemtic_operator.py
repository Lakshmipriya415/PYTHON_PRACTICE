# +, -, *, / ,**, //, %
a=3
b=5
print(a+b)
print(a-b)
print(a*b)
print(a**b)
print(a//b)
print(a%b)
print(a/b)
