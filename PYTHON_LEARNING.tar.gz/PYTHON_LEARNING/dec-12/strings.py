message= "hello"

print(message.upper())
print(message.lower())
print(message.capitalize())
print(message.islower())
print(message.isupper())
print("123".isdigit())
print('A12'.isdigit())
print('12'.isalpha())
