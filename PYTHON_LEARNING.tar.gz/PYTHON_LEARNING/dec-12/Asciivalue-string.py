str1="A"
str2="B"
print(str1>str2)

print(ord(str1))
print(ord("z"))
