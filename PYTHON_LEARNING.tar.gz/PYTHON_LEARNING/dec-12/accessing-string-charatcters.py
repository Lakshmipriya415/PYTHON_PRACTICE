a="Helloeqst"
print(a[5])
print(type(a))
print(type(a[0]))



hello="Message"
for ch in hello:
    print(ch, end="")
