"""text="Hello Worlds"
print(len(text)"""



str1="I love programming"
print(sorted(str1))
