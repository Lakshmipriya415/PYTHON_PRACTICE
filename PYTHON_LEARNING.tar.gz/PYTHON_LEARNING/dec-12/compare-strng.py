a="str1"
b="str2"
print(a==b)



str3="test"
str4="TEST"
print(str3==str4.lower())
