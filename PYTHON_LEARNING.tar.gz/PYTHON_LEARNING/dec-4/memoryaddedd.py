a=5
print(id(a))
b=a
print(id(b))
