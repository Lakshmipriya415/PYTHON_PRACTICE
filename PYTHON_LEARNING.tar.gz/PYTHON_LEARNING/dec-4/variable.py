"""
count=4
print(Count)

1num=4
print(1num)
"""

i=1
i=4
print(i)
i=i+1
print(i)

_j=9
print(_j)

