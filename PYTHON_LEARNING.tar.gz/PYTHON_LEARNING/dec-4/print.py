print("HELLO PYTHON")   
print   ("hello")
print(5 * 5)
print(2+4)
print(5/4)    #This is inline comment
print(10%3)  #(5,20 - operands)


print(5-5)    #(*, +, -, % - operator)
print( 10**3)  #power opeartor
print (5+2+4)   #(5+2+4 - expression)
print (5+5*5)   #* & + works based on precendence
print(5)    #numbers can print but not words or variables

#build-in functions
print(abs(-10.6))   #absolute value removes the negative sign 
print(pow(2,3))    #power function
print(max(23,34,25))
print(min(-23,0,3))


#print('HELLO")   #error
#print "HELLO"  #error



