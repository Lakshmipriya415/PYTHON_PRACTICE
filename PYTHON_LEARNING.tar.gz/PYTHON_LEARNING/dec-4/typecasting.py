"""
implicit type casting 
i=34
j=4.4
print(i+j)


a=4.5
b=1
print(a+b)


c=4.5
d=5+1j
print(c+d)


Explicit type casting
"""


print(str(10.5))

print(int(True))

print(float(True))
