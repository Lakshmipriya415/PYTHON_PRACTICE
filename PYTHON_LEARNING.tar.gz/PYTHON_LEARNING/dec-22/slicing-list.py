number= ["zero","one","two","three","four","five","six","seven","eight","nine","ten"]

print(number[0:4:2])
print(number[: : -1])

del number[:3]
print(number)
