def alternate_merge(list1, list2):
    merged_list = []

    max_len = max(2,3)
    print(max_len)
"""
    for i in range(max_len):
        if i < len(list1):
            merged_list.append(list1[i])
        if i < len(list2):
            merged_list.append(list2[i])

    return merged_list

  """
    
    
print(alternate_merge(['a', 'b'], ['c', 'd', 'e']))  

