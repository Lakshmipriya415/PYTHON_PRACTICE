string="A"
print(ord("A"))


#ascii to character
print(chr(65))
