animals=["giraffee","lion","cat", "elephant", "tiger"]
print(animals)
print(type(animals))

del animals[0]
print(animals)

del animals[0:2]
print(animals)


animals+=["cheetah","rhino"]
print(animals)
