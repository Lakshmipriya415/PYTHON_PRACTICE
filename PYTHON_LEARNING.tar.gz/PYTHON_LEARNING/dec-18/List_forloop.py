
numbers=["one","two","three","four","five","six"]
for i in reversed(numbers):
    print(i,"",end="")
