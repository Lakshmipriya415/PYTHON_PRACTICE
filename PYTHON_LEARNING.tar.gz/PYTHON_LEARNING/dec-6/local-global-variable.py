

def add(x,y):
    z=x+y
    print(z)
    return z

z=add(x=3,y=4)
print(z)

x=10
y=2
z=2
print(x,y,z)
