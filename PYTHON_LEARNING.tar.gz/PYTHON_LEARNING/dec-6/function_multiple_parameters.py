def product(a, b):
    multiply = a * b
    return multiply

result = product(3, 2)
print(result)

