
def print_hello(no_of_times):
    for i in range(0, no_of_times):
        print("print_hello_world")

print_hello(5)

print_hello(3)



