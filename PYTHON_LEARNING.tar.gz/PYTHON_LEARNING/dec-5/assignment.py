"""
a=10
b=3
a//=b 
print(b)
b **=2
print(b)
"""

"""
a = 6
b = 2
c = a + b
c *= b
b **= a
a %= 3
print(a, b, c)
"""


x = 10
y = 3
z = x % y
print(z)
x = x + y
print(x)
