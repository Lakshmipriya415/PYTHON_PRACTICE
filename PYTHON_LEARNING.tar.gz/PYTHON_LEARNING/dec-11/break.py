"""
for i in range(1, 6):
    if i == 3:
        break
    print(i)
"""

"""
for i in range(1, 6):
    if i == 3:
        continue
    print(i)
"""


"""
for i in range(1, 6):
    if i == 3:
        pass   # does nothing
    print(i)
"""



for i in range(1,21):
    if i==15:
        break 
    print(i,"" ,end='')

print("done")
