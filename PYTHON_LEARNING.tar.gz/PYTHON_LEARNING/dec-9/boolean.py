def can_access_library(age):
    if (age>=18):
        return True
    else:
        return False
print(can_access_library(17))


