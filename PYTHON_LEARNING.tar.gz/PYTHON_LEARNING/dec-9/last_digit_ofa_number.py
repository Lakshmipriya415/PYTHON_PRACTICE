def last_digit_of_number(number):
    last_digit=number%10
    return last_digit
print(last_digit_of_number(222533333333333333333333333))
