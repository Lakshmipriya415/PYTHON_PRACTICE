def print_values(num1,num2,num3):
    print(num1)
    print(num2)
    print(num3)
numbers={60,65,70}
print_values(*numbers)
