num1=4
num2=6
limit=30

for i in range(num1,limit):
    
    if i%4==0:
        print(i)
