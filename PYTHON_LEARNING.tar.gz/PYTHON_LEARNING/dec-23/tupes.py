tuple1="apple","banana","kiwi"
print(tuple1)


print(len(tuple1))

print(tuple1[-1])

a,b,c=tuple1
print(b)





