i=1
while i<=5:
    print("5")
    i+=1
